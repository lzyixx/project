<?php
$mysqli = new mysqli('127.0.0.1', 'root', 'bear');
mysqli_select_db($mysqli,'WangShangJiaoYi');

$DealID = $_POST['DealID'];
$Dealname = $_POST['Dealname'];
$Dealcompanylogoimage = $_POST['Dealcompanylogoimage'];
$Company = $_POST['Company'];
$Companyaddress = $_POST['Companyaddress'];
$Companypostcode = $_POST['Companypostcode'];
$Companycountry = $_POST['Companycountry'];
$Promocode = $_POST['Promocode'];
$Landingpage = $_POST['Landingpage'];
$Catchytagline = $_POST['Catchytagline'];
$Dealdescription = $_POST['Dealdescription'];
$Rewardamount = $_POST['Rewardamount'];
$Rewardunit = $_POST['Rewardunit'];
$Countrylist = $_POST['Countrylist'];
$respectivevalidityperiod = $_POST['respectivevalidityperiod'];
$approval = $_POST['approval'];
$sid = $_GET['ID'];
if($query = @mysqli_query($mysqli, "UPDATE WangShangJiaoYi.deal SET `Deal name`='$Dealname',`Deal company logo image`='$Dealcompanylogoimage',Company='$Company',`Company address`='$Companyaddress',`Company postcode`='$Companypostcode',`Company country`='$Companycountry',`Promo code`='$Promocode' ,`Landing page`='$Landingpage',`Catchy tag line`='$Catchytagline',`Deal description`='$Dealdescription',`Reward amount`='$Rewardamount',`Reward unit`='$Rewardunit',`Country list`='$Countrylist',`respective validity period`='$respectivevalidityperiod' ,`approval`='$approval' WHERE DealID='$sid'")){
    echo "<script> alert('change success');</script>";
    include('index1.php');
}else{
    echo "<script> alert('changefail，please try agin');</script>";
    include('index1.php');
}
