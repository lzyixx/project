<?php
$mysqli = new mysqli('127.0.0.1', 'root', 'bear');
mysqli_select_db($mysqli,'WangShangJiaoYi');

$sid = $_GET['ID'];

$sql = "SELECT * FROM WangShangJiaoYi.deal WHERE DealID ='$sid'";
$result = mysqli_query($mysqli, $sql);
$myrow = mysqli_fetch_row($result);
?>
<!DOCTYPE HTML>
<html>

<head>
    <title></title>
    <meta charset="UTF-8" />
    <link rel="stylesheet" type="text/css" href="1.css" />
</head>

<body>
    <form class="box login" method="post" action="sql_update_submit.php?ID=<?= $myrow[0]; ?>">
        <table border="1" id="table">
            <tr>
                <td>respective validity period</td>
                <td><input type="text" value="<?= $myrow[14] ?>"  tabindex="14" required="" name="respectivevalidityperiod"></td>
            </tr>
            <tr>
                <td>Country list</td>
                <td><input type="text" value="<?= $myrow[13] ?>"  tabindex="13" required="" name="Countrylist"></td>
            </tr>
            <tr>
                <td>Reward unit</td>
                <td><input type="text" value="<?= $myrow[12] ?>"  tabindex="12" required="" name="Rewardunit"></td>
            </tr>
            <tr>
                <td>Reward amount</td>
                <td><input type="text" value="<?= $myrow[11] ?>"  tabindex="11" required="" name="Rewardamount"></td>
            </tr>
            <tr>
                <td>Deal description</td>
                <td><input type="text" value="<?= $myrow[10] ?>"  tabindex="10" required="" name="Dealdescription"></td>
            </tr>
            <tr>
                <td>Catchy tag line</td>
                <td><input type="text" value="<?= $myrow[9] ?>"  tabindex="9" required="" name="Catchytagline"></td>
            </tr>
            <tr>
                <td>Landing page</td>
                <td><input type="text" value="<?= $myrow[8] ?>"  tabindex="8" required="" name="Landingpage"></td>
            </tr>
            <tr>
                <td>Promo code</td>
                <td><input type="text" value="<?= $myrow[7] ?>"  tabindex="7" required="" name="Promocode"></td>
            </tr>
            <tr>
                <td>Company country</td>
                <td><input type="text" value="<?= $myrow[6] ?>"  tabindex="6" required="" name="Companycountry"></td>
            </tr>
            <tr>
                <td>Company postcode</td>
                <td><input type="text" value="<?= $myrow[5] ?>"  tabindex="5" required="" name="Companypostcode"></td>
            </tr>
            <tr>
                <td>Company address</td>
                <td><input type="text" value="<?= $myrow[4] ?>"  tabindex="4" required="" name="Companyaddress"></td>
            </tr>
            <tr>
                <td>Company</td>
                <td><input type="text" value="<?= $myrow[3] ?>"  tabindex="3" required="" name="Company"></td>
            </tr>
            <tr>
                <td>Deal company logo image</td>
                <td><input type="text" value="<?= $myrow[2] ?>"  tabindex="2" required="" name="Dealcompanylogoimage"></td>
            </tr>
            <tr>
                <td>Deal name</td>
                <td><input type="text" value="<?= $myrow[1] ?>"  tabindex="1" required="" name="Dealname"></td>
            </tr>
            <tr>
                <td>approval</td>
                <td>
                    <select value="<?= $myrow[16] ?>"  tabindex="0" required="" name="approval">
                        <option value="no">no</option>
                        <option value="yes">yes</option>
                    </select>
                </tr>
            </table>
            <div style="text-align: center;">
                <input type="submit" class="btnLogin" value="submit" tabindex="4" name="login">

            </div>
        </form>
    </body>

    </html>