<?php
$mysqli = new mysqli('127.0.0.1', 'root', 'root');
mysqli_select_db($mysqli,'WangShangJiaoYi');
$delID = $_GET['ID'];
if (mysqli_query($mysqli, "delete from WangShangJiaoYi.deal WHERE DealID ='$delID'")) {
    echo "<script> alert('删除成功');</script>";
    include('index1.php');
}else{
    echo "<script> alert('删除失败');</script>";
}


