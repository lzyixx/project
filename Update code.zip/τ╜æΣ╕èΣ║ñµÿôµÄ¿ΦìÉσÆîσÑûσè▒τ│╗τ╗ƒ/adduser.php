
<?php
$conn=mysqli_connect("127.0.0.1","root","bear","WangShangJiaoYi") or die("数据库连接fail");
mysqli_query($conn,"set names 'utf8'");

$username=$_POST["username"];
$password=$_POST["password"];
$password1=$_POST["password1"];

$XingMing=$_POST["XingMing"];
$XingBie=$_POST["XingBie"];
$DianZiYouJian=$_POST["DianZiYouJian"];
$DiZhi=$_POST["DiZhi"];
$YouBian=$_POST["YouBian"];
$GuoJia=$_POST["GuoJia"];

date_default_timezone_set('PRC');
$time=date('Y-m-d H:i:s');
$usernameSQL="select * from user where username='$username'";
$resultSet=mysqli_query($conn,$usernameSQL);
if(mysqli_num_rows($resultSet)>0)
{
	echo "<script language='JavaScript'>;alert('acount has regist！！');history.back(-1);</script>;";
}
else{
	if(strlen($password)<6 && strlen($password1)<6){
		echo "<script language='JavaScript'>;alert('password too short');history.back(-1);</script>;";
	}else{
		if($password != $password1){
			echo "<script language='JavaScript'>;alert('password is difreent');history.back(-1);</script>;";
		   }else{
			      $insert_sql=" insert into user values(null,'$username','$password',0,1,'$time','$XingMing','$XingBie','$DianZiYouJian','$DiZhi','$YouBian','$GuoJia')";
                  $insert=mysqli_query($conn,$insert_sql);
                  if($insert){
	                    	echo '<script language="JavaScript">;alert("add success");location.href="index0.php";</script>;';
	                }else {
	                   echo '<script language="JavaScript"> alert("fail！")</script>';
		                  }
			    }
		}
}


?>
