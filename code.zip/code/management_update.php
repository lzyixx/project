<?php
$mysqli = new mysqli('127.0.0.1', 'root', 'bear');
mysqli_select_db($mysqli,'WangShangJiaoYi');

$sid = $_GET['ID'];

$sql = "SELECT * FROM WangShangJiaoYi.user WHERE ID ='$sid'";
$result = mysqli_query($mysqli, $sql);
$myrow = mysqli_fetch_row($result);
?>

<!DOCTYPE HTML>
<html>
<head>
    <title></title>
    <meta charset="UTF-8"/>
    <link rel="stylesheet" type="text/css" href="1.css"/>
</head>

<body>
<form class="box login" method="post" action="management_update_submit.php?ID=<?= $myrow[0]; ?>" >

            <div class="item">
                <input type="text"  id="username" name="username"  placeholder="Set account number (6-11 digits)" maxlength="11" class="text_field"  onfocus="un()" onblur="un()"  required="required" value="<?= $myrow[1] ?>"/>
                <div class="usedemo"><span  class="demo" id="demo" name="demo"></span></div>
            </div>

            <div class="item">
                <input type="text"  id="XingMing" name="XingMing"  placeholder="name" class="text_field" required="required" value="<?= $myrow[6] ?>"/>
                <div class="usedemo"><span  class="demo" id="demo" name="demo"></span></div>
            </div>
            <div class="item">
                <select class="text_field" id="XingBie" name="XingBie" value="<?= $myrow[7] ?>">
                    <option value="male">male</option>
                    <option value="female">female</option>
                </select>
            </div>
            <div class="item">
                <input value="<?= $myrow[8] ?>" type="text"  id="DianZiYouJian" name="DianZiYouJian"  placeholder="email" class="text_field" required="required"/>
            </div>
            <div class="item">
                <input value="<?= $myrow[4] ?>" type="text"  id="permissions" name="permissions"  placeholder="permissions" class="text_field" required="required"/>
            </div>
            <div class="item">
                <input value="<?= $myrow[9] ?>" type="text"  id="DiZhi" name="DiZhi"  placeholder="address" class="text_field" required="required"/>
            </div>
            <div class="item">
                <input value="<?= $myrow[10] ?>" type="text"  id="YouBian" name="YouBian"  placeholder="postcode" class="text_field" required="required"/>
            </div>
            <div class="item">
                <input value="<?= $myrow[11] ?>" type="text"  id="GuoJia" name="GuoJia"  placeholder="country" class="text_field" required="required"/>
            </div>

            <div class="item">
                <input value="<?= $myrow[2] ?>"  type="password" id="password" name="password"  placeholder="set password" maxlength="16" class="text_field" onblur="pw()" onfocus="pw()" required="required"/>
                <div class="pwdemo"><span class="demo" id="demo1"></span></div>
            </div>


<input type="submit" class="btnLogin" value="submit" tabindex="4" name="login">
</form>
</body>
</html>

