<?php
$mysqli = new mysqli('127.0.0.1', 'root', 'bear');
mysqli_select_db($mysqli,'WangShangJiaoYi');

$DealID = $_POST['Deal ID'];
$Dealname = $_POST['Deal name'];
$Dealcompanylogoimage = $_POST['Deal company logo image'];
$Company = $_POST['Company'];
$Companyaddress = $_POST['Company address'];
$Companypostcode = $_POST['Company postcode'];
$Companycountry = $_POST['Company country'];
$Promocode = $_POST['Promo code'];
$Landingpage = $_POST['Landing page'];
$Catchytagline = $_POST['Catchy tag line'];
$Dealdescription = $_POST['Deal description'];
$Rewardamount = $_POST['Reward amount'];
$Rewardunit = $_POST['Reward unit'];
$Countrylist = $_POST['Country list'];
$respectivevalidityperiod = $_POST['respective validity period'];

$sid = $_GET['ID'];

if($query = @mysqli_query($mysqli, "UPDATE WangShangJiaoYi.user SET UserName='$username',XingMing='$XingMing',XingBie='$XingBie',DianZiYouJian='$DianZiYouJian',DiZhi='$DiZhi',YouBian='$YouBian',GuoJia='$GuoJia',password='$password' ,permissions='$permissions' WHERE ID='$sid'")){
    echo "<script> alert('change success');</script>";
    include('index0.php');
}else{
    echo "<script> alert('changefail，please try agin');</script>";
    include('index0.php');
}
