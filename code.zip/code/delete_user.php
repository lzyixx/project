<?php
$mysqli = new mysqli('127.0.0.1', 'root', 'bear');
mysqli_select_db($mysqli,'WangShangJiaoYi');
$delID = $_GET['ID'];
if (mysqli_query($mysqli, "delete from WangShangJiaoYi.user WHERE ID ='$delID'")) {
    echo "<script> alert('successfully delete
    ');</script>";
    include('index0.php');
}else{
    echo "<script> alert('fail to delete
    ');</script>";
    include('script.php');
}