<?php
$mysqli = new mysqli('127.0.0.1', 'root', 'bear');
mysqli_select_db($mysqli,'WangShangJiaoYi');

$username = $_POST['username'];
$XingMing = $_POST['XingMing'];
$XingBie = $_POST['XingBie'];
$DianZiYouJian = $_POST['DianZiYouJian'];
$DiZhi = $_POST['DiZhi'];
$YouBian = $_POST['YouBian'];
$GuoJia = $_POST['GuoJia'];
$password = $_POST['password'];
$permissions = $_POST['permissions'];

$sid = $_GET['ID'];

if($query = @mysqli_query($mysqli, "UPDATE WangShangJiaoYi.user SET UserName='$username',XingMing='$XingMing',XingBie='$XingBie',DianZiYouJian='$DianZiYouJian',DiZhi='$DiZhi',YouBian='$YouBian',GuoJia='$GuoJia',password='$password' ,permissions='$permissions' WHERE ID='$sid'")){
    echo "<script> alert('success');</script>";
    include('index0.php');
}else{
    echo "<script> alert('try again');</script>";
    include('index0.php');
}
