<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>login</title>
<style type="text/css">
#login_frame {
	width: 339.9px;
	height: 400px;
	padding: 13px;
	position: absolute;
	left: 50%;
	top: 50%;
	margin-left: -200px;
	margin-top: -200px;
	background-color: rgba(255,255,255,0.5);
	border-radius: 10px;
	text-align: center;
}
#return_index {
	position: relative;
	float: left;
	color:rgba(255,255,255,1);
	font-family: "Arial";
}
#return_login {
	float: right;
	color:rgba(255,255,255,1);
	font-family: "Arial";
}
.text_field {
	height: 42px;
	width: 300px;
	border-radius: 10px;
	border: 1;
	vertical-align: middle;
	font-size: 20px;
	font-family: "Arial";
}
#but_login {
	width: 300px;
	height: 42px;
	background-color: #dbc594;
	border-radius: 6px;
	border: 0;
	color: rgba(255,255,255,1);
	font-size: 20px;
	font-family: "Arial";
}
#login {
	vertical-align: middle;
	padding-top: 20px;
}
.item {
	width: 300px;
	height: 42px;
	margin: 40px auto;
	position: relative;
}
.usedemo {
	width: 300px;
	height: 20px;
	margin: 0px auto;
	text-align: center;
}
.pwdemo {
	width: 300px;
	height: 20px;
	margin: 0px auto;
	text-align: center;
}
.demo {
	width: 300px;
	text-align: left;
	font-size: 18px;
	line-height: 12px;
	position: relative;
	float: left;
	height: 20px;
	font-family: "Arial";
	margin-top: 10px;
}
</style>

<script type="text/javascript">
      function un(){
         var username=document.getElementById("username").value;
	          if (isNaN(username) || username.length<6) {
				  document.getElementById("demo").innerHTML = "<font color='red'>error</font>";
				  return false;
              } else {
									 document.getElementById("demo").innerHTML = "<font color='green'>√</font>";
									 return true;
                     }
		 }
	  function pw(){
		   var password=document.getElementById("password").value;
			   if(password.length<6){
				   document.getElementById("demo1").innerHTML = "<font color='red'>at list 6 chars</font>";
				   return false;
				   }else{
					         document.getElementById("demo1").innerHTML = "<font color='green'>√</font>";
							 return true;
					   }
		 }
</script>
</head>

<body style=" background-image:url(./16pic_6137400_b2.jpg); background-size:100%; background-repeat:no-repeat;">
<div  class="login" id="login_frame">
     
     <form id="login" action="loginsql.php" method="post">
    
     <div class="item">
           <input type="text"  id="username" name="username"  placeholder="acount" maxlength="11" class="text_field"  onfocus="un()" onblur="un()"  required="required"/>
           <div class="usedemo"><span  class="demo" id="demo" name="demo"></span></div>
     </div>
     
     <div class="item">
           <input type="password" id="password" name="password"  placeholder="password" maxlength="16" class="text_field" onblur="pw()" onfocus="pw()" required="required"/>
           <div class="pwdemo"><span class="demo" id="demo1"></span></div>
     </div>
        
      <div class="item">
           <div id="login_control">
           <?php //<a id="return_login"; href="***" > forget password？</a> ?>
           <input type="submit" name="button" id="but_login" value="login"/>
           <a id="return_login"; href="register.php" >regist</a>
            <div style="overflow: hidden;clear: both;"></div> </br>
<!--            <a id="return_login"; href="register1.php" >registered dealer</a>
 -->           </div>
      </div>
  </form>

</div>
</body>
</html>
