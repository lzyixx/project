<!DOCTYPE HTML>
<html>
<head>
    <title></title>
    <meta charset="UTF-8"/>
    <link rel="stylesheet" type="text/css" href="1.css"/>
</head>

<body>
        <form id="logon" action="adduser.php" method="post">
            <div class="item">
                <input type="text"  id="username" name="username"  placeholder="acount" maxlength="11" class="text_field"  onfocus="un()" onblur="un()"  required="required"/>
                <div class="usedemo"><span  class="demo" id="demo" name="demo"></span></div>
            </div>
            <div class="item">
                <input type="text"  id="XingMing" name="XingMing"  placeholder="name" class="text_field" required="required"/>
                <div class="usedemo"><span  class="demo" id="demo" name="demo"></span></div>
            </div>
            <div class="item">
                <select class="text_field" id="XingBie" name="XingBie">
                    <option value="man">man</option>
                    <option value="woman">woman</option>
                </select>
            </div>
            <div class="item">
                <input type="text"  id="DianZiYouJian" name="DianZiYouJian"  placeholder="email" class="text_field" required="required"/>
            </div>
            <div class="item">
                <input type="text"  id="DiZhi" name="DiZhi"  placeholder="address" class="text_field" required="required"/>
            </div>
            <div class="item">
                <input type="text"  id="YouBian" name="YouBian"  placeholder="code" class="text_field" required="required"/>
            </div>
            <div class="item">
                <input type="text"  id="GuoJia" name="GuoJia"  placeholder="contry" class="text_field" required="required"/>
            </div>

            <div class="item">
                <input type="password" id="password" name="password"  placeholder="password" maxlength="16" class="text_field" onblur="pw()" onfocus="pw()" required="required"/>
                <div class="pwdemo"><span class="demo" id="demo1"></span></div>
            </div>

            <div class="item">
                <input type="password" id="password1" name="password1"  placeholder="comfirm password" maxlength="16" class="text_field"  required="required"/> 
                <div class="pw1demo"><span class="demo" id="demo2"></span></div>
            </div>

            <div class="item">
                <div id="login_control">
                    <input type="submit" name="button" id="but_logon" value="add"/>
                </div>
            </div>
        </form>
</body>
</html>