<?php
$mysqli = new mysqli('127.0.0.1', 'root', 'bear');
mysqli_select_db($mysqli,'WangShangJiaoYi');

$result = mysqli_query($mysqli, "SELECT * FROM WangShangJiaoYi.deal") or die("fail");
?>
<!DOCTYPE HTML>
<html>
<head>
    <title>Online Deal Referral and Reward System</title>
    <style>
    </style>    <link rel="stylesheet" type="text/css" href="1.css"/>

</head>

<body>
    <h1 class="pagetitle" align="center">Online Deal Referral and Reward System</h1>

    <nav>
        <hr>
        <p align="center">
            <a href="index0.php">user manager</a>
            <a href="index1.php">deals  manager</a>
            <a href="record.php">record</a>
            <a href="report.php">report</a>

            <a href="login.php">exit</a>
        </p>
        <hr>
    </nav>

    <div>



        <table border="1" width="70%" align="center">
            <tr>
                <th width="5%">Deal ID</th>
                <th width="5%">Deal name</th>
                <th width="5%">Deal company logo image</th>
                <th width="5%">Company</th>
                <th width="5%">Company address</th>
                <th width="5%">Company postcode</th>
                <th width="5%">Company country</th>
                <th width="5%">Promo code</th>
                <th width="5%">Landing page</th>
                <th width="5%">Catchy tag line</th>
                <th width="5%">Deal description</th>
                <th width="5%">Reward amount</th>
                <th width="5%">Reward unit</th>
                <th width="5%">Country list</th>
                <th width="5%">respective validity period</th>
                <th width="5%">time</th>
                <th width="5%">approval</th>
                <th width="5%">person</th>

                <th width="5%">update</th>
                <th width="5%">delete</th>
            </tr>
            <?php

            while ($myrow = mysqli_fetch_row($result)) {
                ?>
                <tr>
                    <td align="center"><?php echo $myrow[0]; ?></td>
                    <td align="center"><?php echo $myrow[1]; ?></td>
                    <td align="center"><?php echo $myrow[2]; ?></td>
                    <td align="center"><?php echo $myrow[3]; ?></td>
                    <td align="center"><?php echo $myrow[4]; ?></td>
                    <td align="center"><?php echo $myrow[5]; ?></td>
                    <td align="center"><?php echo $myrow[6]; ?></td>
                    <td align="center"><?php echo $myrow[7]; ?></td>
                    <td align="center"><?php echo $myrow[8]; ?></td>
                    <td align="center"><?php echo $myrow[9]; ?></td>
                    <td align="center"><?php echo $myrow[10]; ?></td>
                    <td align="center"><?php echo $myrow[11]; ?></td>
                    <td align="center"><?php echo $myrow[12]; ?></td>
                    <td align="center"><?php echo $myrow[13]; ?></td>
                    <td align="center"><?php echo $myrow[14]; ?></td>
                    <td align="center"><?php echo $myrow[15]; ?></td>
                    <td align="center"><?php echo $myrow[16]; ?></td>
                    <td align="center"><?php echo $myrow[17]; ?></td>
                    <td align="center"><a href="deal_update.php?ID=<?=$myrow[0]?>">update</a></td>
                    <td align="center"><a href="delete_deal.php?ID=<?=$myrow[0]?>" onclick="return confirm('delete?')" >delete</a></td>
                    </tr><?php
                } ?>
            </table>
        </div>

        <div>
            <p align="center">
                <a href="add_deal.php">add</a>
                </>
            </div>

            <nav>
                <p align="right">
                    <a>copy right</a>
                </p>
            </nav>
        </div>
    </body>
    </html>