
<?php
$conn=mysqli_connect("127.0.0.1","root","root","WangShangJiaoYi") or die("数据库连接失败");
mysqli_query($conn,"set names 'utf8'");

$DealID = $_POST['DealID'];
$Dealname = $_POST['Dealname'];
$Dealcompanylogoimage = $_POST['Dealcompanylogoimage'];
$Company = $_POST['Company'];
$Companyaddress = $_POST['Companyaddress'];
$Companypostcode = $_POST['Companypostcode'];
$Companycountry = $_POST['Companycountry'];
$Promocode = $_POST['Promocode'];
$Landingpage = $_POST['Landingpage'];
$Catchytagline = $_POST['Catchytagline'];
$Dealdescription = $_POST['Dealdescription'];
$Rewardamount = $_POST['Rewardamount'];
$Rewardunit = $_POST['Rewardunit'];
$Countrylist = $_POST['Countrylist'];
$respectivevalidityperiod = $_POST['respectivevalidityperiod'];

date_default_timezone_set('PRC');
$time=date('Y-m-d H:i:s');

$insert_sql=" insert into deal values(null,'$Dealname','$Dealcompanylogoimage','$Company','$Companyaddress','$Companypostcode','$Companycountry','$Promocode','$Landingpage','$Catchytagline','$Dealdescription','$Rewardamount','$Rewardunit','$Countrylist','$respectivevalidityperiod','$time','no')";
    $insert=mysqli_query($conn,$insert_sql);
    if($insert){
          	echo '<script language="JavaScript">;alert("add success");window.history.go(-2);</script>;';
      }else {
         echo '<script language="JavaScript"> alert("失败！")</script>';
            }

?>
