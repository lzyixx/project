<?php
$mysqli = new mysqli('127.0.0.1', 'root', 'bear');
mysqli_select_db($mysqli,'WangShangJiaoYi');

$result = mysqli_query($mysqli, "SELECT * FROM WangShangJiaoYi.deal") or die("fail");
?>
<!DOCTYPE HTML>
<html>
<head>
    <title>Online Deal Referral and Reward System</title>
    <style>
    </style>    <link rel="stylesheet" type="text/css" href="1.css"/>
    <script type="text/javascript" src="echarts.min.js"></script>
</head>

<body>
    <h1 class="pagetitle" align="center">Online Deal Referral and Reward System</h1>

    <nav>
        <hr>
        <p align="center">
            <a href="index0.php">user manager</a>
            <a href="index1.php">deals  manager</a>
            <a href="record.php">record</a>
            <a href="report.php">report</a>

            <a href="login.php">exit</a>
        </p>
        <hr>
    </nav>

<div id="main" style="height: 500px;width: 500px;margin-left: auto;margin-right: auto;"></div>
    <div>

        <script type="text/javascript">
            var chartDom = document.getElementById('main');
            var myChart = echarts.init(chartDom);
            var option;

            option = {
                title: {
                    text: 'source',
                    subtext: '',
                    left: 'center'
                },
                tooltip: {
                    trigger: 'item'
                },
                legend: {
                    orient: 'vertical',
                    left: 'left',
                },
                series: [
                {
                    name: 'source',
                    type: 'pie',
                    radius: '50%',
                    data: [
                    {value: 1048, name: 'Twitter'},
                    {value: 735, name: 'Facebook'},
                    {value: 580, name: 'Google'},
                    {value: 484, name: 'email'},
                    {value: 300, name: 'SSO'}
                    ],
                    emphasis: {
                        itemStyle: {
                            shadowBlur: 10,
                            shadowOffsetX: 0,
                            shadowColor: 'rgba(0, 0, 0, 0.5)'
                        }
                    }
                }
                ]
            };

            option && myChart.setOption(option);

        </script>

        
    </div>



    <nav>
        <p align="right">
            <a>copy right</a>
        </p>
    </nav>
</div>
</body>
</html>