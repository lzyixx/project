<?php
$conn=mysqli_connect("127.0.0.1","root","bear","WangShangJiaoYi") or die("数据库连接fail");
mysqli_query($conn,"set names 'utf8'");

$username=$_POST["username"];
$password=$_POST["password"];

$s_un="select * from user where username='$username' and permissions in (1,9)";
$s_pw="select UserName,Password from user where UserName='$username'";
$row = mysqli_fetch_array(mysqli_query($conn,$s_pw));

if(mysqli_num_rows(mysqli_query($conn,$s_un))==0){
	echo "<script>;alert('acount not exsit');history.back(-1);</script>;";  
}else{
	if($row['UserName']=="admin" && $row['Password']=="123456")
	{
		setcookie('uname','admin',time()+3600);
		echo "<script>;alert(' login success');location.href='index0.php';</script>;"; 
	}
	else if($row['UserName']==$username && $row['Password']==$password)
	{
		setcookie('uname',$username,time()+3600);
		echo "<script>;alert('login success');location.href='index2.php';</script>;";  	
	}else{
		echo "<script>;alert('acount or password  error');history.back(-1);</script>;"; 
	}
}
?>