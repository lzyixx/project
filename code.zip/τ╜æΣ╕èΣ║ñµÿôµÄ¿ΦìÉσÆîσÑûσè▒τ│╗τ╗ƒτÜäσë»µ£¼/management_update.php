<?php
$mysqli = new mysqli('127.0.0.1', 'root', 'root');
mysqli_select_db($mysqli,'WangShangJiaoYi');

$sid = $_GET['ID'];

$sql = "SELECT * FROM WangShangJiaoYi.user WHERE ID ='$sid'";
$result = mysqli_query($mysqli, $sql);
$myrow = mysqli_fetch_row($result);
?>

<!DOCTYPE HTML>
<html>
<head>
    <title></title>
    <meta charset="UTF-8"/>
    <link rel="stylesheet" type="text/css" href="1.css"/>
</head>

<body>
<form class="box login" method="post" action="management_update_submit.php?ID=<?= $myrow[0]; ?>" >

            <div class="item">
                <input type="text"  id="username" name="username"  placeholder="设 置 账 号(6-11位数字)" maxlength="11" class="text_field"  onfocus="un()" onblur="un()"  required="required" value="<?= $myrow[1] ?>"/>
                <div class="usedemo"><span  class="demo" id="demo" name="demo"></span></div>
            </div>

            <div class="item">
                <input type="text"  id="XingMing" name="XingMing"  placeholder="姓名" class="text_field" required="required" value="<?= $myrow[6] ?>"/>
                <div class="usedemo"><span  class="demo" id="demo" name="demo"></span></div>
            </div>
            <div class="item">
                <select class="text_field" id="XingBie" name="XingBie" value="<?= $myrow[7] ?>">
                    <option value="男">男</option>
                    <option value="女">女</option>
                </select>
            </div>
            <div class="item">
                <input value="<?= $myrow[8] ?>" type="text"  id="DianZiYouJian" name="DianZiYouJian"  placeholder="电子邮件" class="text_field" required="required"/>
            </div>
            <div class="item">
                <input value="<?= $myrow[4] ?>" type="text"  id="permissions" name="permissions"  placeholder="permissions" class="text_field" required="required"/>
            </div>
            <div class="item">
                <input value="<?= $myrow[9] ?>" type="text"  id="DiZhi" name="DiZhi"  placeholder="地址" class="text_field" required="required"/>
            </div>
            <div class="item">
                <input value="<?= $myrow[10] ?>" type="text"  id="YouBian" name="YouBian"  placeholder="邮政编码" class="text_field" required="required"/>
            </div>
            <div class="item">
                <input value="<?= $myrow[11] ?>" type="text"  id="GuoJia" name="GuoJia"  placeholder="国家" class="text_field" required="required"/>
            </div>

            <div class="item">
                <input value="<?= $myrow[2] ?>"  type="password" id="password" name="password"  placeholder="设 置 密 码" maxlength="16" class="text_field" onblur="pw()" onfocus="pw()" required="required"/>
                <div class="pwdemo"><span class="demo" id="demo1"></span></div>
            </div>


<input type="submit" class="btnLogin" value="提交" tabindex="4" name="login">
</form>
</body>
</html>

