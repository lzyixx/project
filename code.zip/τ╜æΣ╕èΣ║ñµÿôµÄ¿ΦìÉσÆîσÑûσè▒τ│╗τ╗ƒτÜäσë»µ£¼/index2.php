<?php
$mysqli = new mysqli('127.0.0.1', 'root', 'root');
mysqli_select_db($mysqli,'WangShangJiaoYi');

$result = mysqli_query($mysqli, "SELECT * FROM WangShangJiaoYi.deal where approval = 'yes' order by time asc") or die("失败");
?>
<!DOCTYPE HTML>
<html>
<head>
    <title>Online Deal Referral and Reward System</title>
    <style>
    </style>    <link rel="stylesheet" type="text/css" href="1.css"/>
    <style>


        #container {
            width: 500px;
            margin: 0 auto;
        }
        div.search {padding: 30px 0;}

        form {
            position: relative;
            width: 300px;
            margin: 0 auto;
        }

        input, button {
            border: none;
            outline: none;
        }

        input {
            width: 100%;
            height: 42px;
            padding-left: 13px;
        }

        button {
            height: 42px;
            width: 42px;
            cursor: pointer;
            position: absolute;
        }

        /*搜索框1*/
        .bar1 {background: #A3D0C3;}
        .bar1 input {
            border: 2px solid #7BA7AB;
            border-radius: 5px;
            background: #F9F0DA;
            color: #9E9C9C;
        }
        .bar1 button {
            top: 0;
            right: 0;
            background: transparent;
            border-radius: 0 5px 5px 0;
        }
        .bar1 button:before {
            content: "\f002";
            font-family: FontAwesome;
            font-size: 16px;
            color: #F9F0DA;
        }

        /*搜索框2*/
        .bar2 {background: #DABB52;}
        .bar2 input, .bar2 button {
            border-radius: 3px;
        }
        .bar2 input {
            background: #F9F0DA;
        }
        .bar2 button {
            height: 26px;
            width: 26px;
            top: 8px;
            right: 8px;
            background: #F15B42;
        }
        .bar2 button:before {
            content: "\f105";
            font-family: FontAwesome;
            color: #F9F0DA;
            font-size: 20px;
            font-weight: bold;
        }

        /*搜索框3*/
        .bar3 {background: #F9F0DA;}
        .bar3 form {background: #A3D0C3;}
        .bar3 input, .bar3 button {
            background: transparent;
        }
        .bar3 button {
            top: 0;
            right: 0;
        }
        .bar3 button:before {
            content: "\f002";
            font-family: FontAwesome;
            font-size: 16px;
            color: #F9F0DA;
        }

        /*搜索框4*/
        .bar4 {background: #F15B42;}
        .bar4 form {
            background: #F9F0DA;
            border-bottom: 2px solid #BE290E;
        }
        .bar4 input, .bar4 button {
            background: transparent;
        }
        .bar4 button {
            top: 0;
            right: 0;
        }
        .bar4 button:before {
            content: "\f178";
            font-family: FontAwesome;
            font-size: 20px;
            color: #be290e;
        }

        /*搜索框5*/
        .bar5 {background: #683B4D;}
        .bar5 input, .bar5 button {
            background: transparent;
        }
        .bar5 input {
            border: 2px solid #F9F0DA;
        }
        .bar5 button {
            top: 0;
            right: 0;
        }
        .bar5 button:before {
            content: "\f002";
            font-family: FontAwesome;
            font-size: 16px;
            color: #F9F0DA;
        }
        .bar5 input:focus {
            border-color: #311c24
        }

        /*搜索框6*/
        .bar6 {background: #F9F0DA;}
        .bar6 input {
            border: 2px solid #c5464a;
            border-radius: 5px;
            background: transparent;
            top: 0;
            right: 0;
        }
        .bar6 button {
            background: #c5464a;
            border-radius: 0 5px 5px 0;
            width: 60px;
            top: 0;
            right: 0;
        }
        .bar6 button:before {
            content: "搜索";
            font-size: 13px;
            color: #F9F0DA;
        }


        /*搜索框7*/
        .bar7 {background: #7BA7AB;}
        .bar7 form {
            height: 42px;
        }
        .bar7 input {
            width: 250px;
            border-radius: 42px;
            border: 2px solid #324B4E;
            background: #F9F0DA;
            transition: .3s linear;
            float: right;
        }
        .bar7 input:focus {
            width: 300px;
        }
        .bar7 button {
            background: none;
            top: -2px;
            right: 0;
        }
        .bar7 button:before{
          content: "\f002";
          font-family: FontAwesome;
          color: #324b4e;
      }

      /*搜索框8*/
      .bar8 {background: #B46381;}
      .bar8 form {
        height: 42px;
    }
    .bar8 input {
        width: 0;
        padding: 0 42px 0 15px;
        border-bottom: 2px solid transparent;
        background: transparent;
        transition: .3s linear;
        position: absolute;
        top: 0;
        right: 0;
        z-index: 2;
    }
    .bar8 input:focus {
        width: 300px;
        z-index: 1;
        border-bottom: 2px solid #F9F0DA;
    }
    .bar8 button {
        background: #683B4D;
        top: 0;
        right: 0;
    }
    .bar8 button:before {
        content: "\f002";
        font-family: FontAwesome;
        font-size: 16px;
        color: #F9F0DA;
    }
</style>
</head>

<body>
    <h1 class="pagetitle" align="center">Online Deal Referral and Reward System</h1>

    <nav>
        <hr>
        <p align="center">
            <a href="index1.php">deals  manager</a>
            <a href="login.php">exit</a>
        </p>
        <hr>
    </nav>

    <div>
        <div id="container" style="margin-bottom: 15px">
            <div class="search bar1">
                <form>
                    <input id="tf" type="text" placeholder="search...">
                    <button id="btn" type="button">search</button>
                </form>
            </div>
        </div>

        <script src="https://cdn.bootcdn.net/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
        <script type="text/javascript">
            $('#btn').click(function(){
                $('tr').each(function(i,o){
                    if ($(o).attr('id')=='tou') {

                    }else{
                        $(o).hide()

                    }
                })
                $('td').each(function(i,o){
                    if ($(o).text().indexOf($('#tf').val())!=-1) {
                        $(o).parent().show()
                    }
                })
                if ($('#tf').val()=='') {
                $('tr').each(function(i,o){
                    if ($(o).attr('id')=='tou') {

                    }else{
                        $(o).show()

                    }
                })
                }
            })
        </script>
        <table border="1" width="70%" align="center">
            <tr id="tou">
                <th width="5%">Deal ID</th>
                <th width="5%">Deal name</th>
                <th width="5%">Deal company logo image</th>
                <th width="5%">Company</th>
                <th width="5%">Company address</th>
                <th width="5%">Company postcode</th>
                <th width="5%">Company country</th>
                <th width="5%">Promo code</th>
                <th width="5%">Landing page</th>
                <th width="5%">Catchy tag line</th>
                <th width="5%">Deal description</th>
                <th width="5%">Reward amount</th>
                <th width="5%">Reward unit</th>
                <th width="5%">Country list</th>
                <th width="5%">respective validity period</th>
                <th width="5%">time</th>
            </tr>
            <?php

            while ($myrow = mysqli_fetch_row($result)) {
                ?>
                <tr>
                    <td align="center"><?php echo $myrow[0]; ?></td>
                    <td align="center"><?php echo $myrow[1]; ?></td>
                    <td align="center"><?php echo $myrow[2]; ?></td>
                    <td align="center"><?php echo $myrow[3]; ?></td>
                    <td align="center"><?php echo $myrow[4]; ?></td>
                    <td align="center"><?php echo $myrow[5]; ?></td>
                    <td align="center"><?php echo $myrow[6]; ?></td>
                    <td align="center"><?php echo $myrow[7]; ?></td>
                    <td align="center"><?php echo $myrow[8]; ?></td>
                    <td align="center"><?php echo $myrow[9]; ?></td>
                    <td align="center"><?php echo $myrow[10]; ?></td>
                    <td align="center"><?php echo $myrow[11]; ?></td>
                    <td align="center"><?php echo $myrow[12]; ?></td>
                    <td align="center"><?php echo $myrow[13]; ?></td>
                    <td align="center"><?php echo $myrow[14]; ?></td>
                    <td align="center"><?php echo $myrow[15]; ?></td>
                    </tr><?php
                } ?>
            </table>
        </div>

        <div>
            <p align="center">
                <a href="add_deal.php">add</a>
                </>
            </div>

            <nav>
                <p align="right">
                    <a>copy right</a>
                </p>
            </nav>
        </div>
    </body>
    </html>