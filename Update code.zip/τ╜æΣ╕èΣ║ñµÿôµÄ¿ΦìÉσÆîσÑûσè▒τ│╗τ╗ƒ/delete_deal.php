<?php
$mysqli = new mysqli('127.0.0.1', 'root', 'bear');
mysqli_select_db($mysqli,'WangShangJiaoYi');
$delID = $_GET['ID'];
if (mysqli_query($mysqli, "delete from WangShangJiaoYi.deal WHERE DealID ='$delID'")) {
    echo "<script> alert('delete success');</script>";
    include('index1.php');
}else{
    echo "<script> alert('delete fail');</script>";
}


