<!DOCTYPE HTML>
<html>
<head>
    <title></title>
    <meta charset="UTF-8"/>
    <link rel="stylesheet" type="text/css" href="1.css"/>
</head>

<body>
        <form id="logon" action="adduser.php" method="post">
            <div class="item">
                <input type="text"  id="username" name="username"  placeholder="设 置 账 号(6-11位数字)" maxlength="11" class="text_field"  onfocus="un()" onblur="un()"  required="required"/>
                <div class="usedemo"><span  class="demo" id="demo" name="demo"></span></div>
            </div>
            <div class="item">
                <input type="text"  id="XingMing" name="XingMing"  placeholder="姓名" class="text_field" required="required"/>
                <div class="usedemo"><span  class="demo" id="demo" name="demo"></span></div>
            </div>
            <div class="item">
                <select class="text_field" id="XingBie" name="XingBie">
                    <option value="男">男</option>
                    <option value="女">女</option>
                </select>
            </div>
            <div class="item">
                <input type="text"  id="DianZiYouJian" name="DianZiYouJian"  placeholder="电子邮件" class="text_field" required="required"/>
            </div>
            <div class="item">
                <input type="text"  id="DiZhi" name="DiZhi"  placeholder="地址" class="text_field" required="required"/>
            </div>
            <div class="item">
                <input type="text"  id="YouBian" name="YouBian"  placeholder="邮政编码" class="text_field" required="required"/>
            </div>
            <div class="item">
                <input type="text"  id="GuoJia" name="GuoJia"  placeholder="国家" class="text_field" required="required"/>
            </div>

            <div class="item">
                <input type="password" id="password" name="password"  placeholder="设 置 密 码" maxlength="16" class="text_field" onblur="pw()" onfocus="pw()" required="required"/>
                <div class="pwdemo"><span class="demo" id="demo1"></span></div>
            </div>

            <div class="item">
                <input type="password" id="password1" name="password1"  placeholder="确 认 密 码" maxlength="16" class="text_field"  required="required"/> 
                <div class="pw1demo"><span class="demo" id="demo2"></span></div>
            </div>

            <div class="item">
                <div id="login_control">
                    <input type="submit" name="button" id="but_logon" value="add"/>
                </div>
            </div>
        </form>
</body>
</html>