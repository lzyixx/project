<?php
$mysqli = new mysqli('127.0.0.1', 'root', 'bear');
mysqli_select_db($mysqli,'WangShangJiaoYi');

$result = mysqli_query($mysqli, "SELECT * FROM WangShangJiaoYi.deal") or die("fail");
?>
<!DOCTYPE HTML>
<html>
<head>
    <title>Online Deal Referral and Reward System</title>
    <style>
    </style>    <link rel="stylesheet" type="text/css" href="1.css"/>

</head>

<body>
    <h1 class="pagetitle" align="center">Online Deal Referral and Reward System</h1>

    <nav>
        <hr>
        <p align="center">
            <a href="index0.php">user manager</a>
            <a href="index1.php">deals  manager</a>
            <a href="record.php">record</a>
            <a href="report.php">report</a>
            <a href="login.php">exit</a>
        </p>
        <hr>
    </nav>

    <div>



        <table border="1" width="70%" align="center">
            <tr>
                <th width="5%">IP address</th>
                <th width="5%">referrer</th>
                <th width="5%">referral channel</th>

            </tr>
            <?php

            while ($myrow = mysqli_fetch_row($result)) {
                ?>
                <tr>

                    </tr><?php
                } ?>
            </table>
        </div>


            <nav>
                <p align="right">
                    <a>copy right</a>
                </p>
            </nav>
        </div>
    </body>
    </html>