<!DOCTYPE HTML>
<html>
<head>
    <title></title>
    <meta charset="UTF-8"/>
    <link rel="stylesheet" type="text/css" href="1.css"/>
</head>

<body>
    <form class="box login" method="post" action="adddealsql.php">
        <table border="1" id="table">
        </table>

        <div style="text-align: center;">
            <input type="submit" class="btnLogin" value="submit" tabindex="5" name="login">
        </div>
    </form>
    <script src="https://cdn.bootcdn.net/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script type="text/javascript">
        var arr = ["Deal name","Deal company logo image","Company","Company address","Company postcode","Company country","Promo code","Landing page","Catchy tag line","Deal description","Reward amount","Reward unit","Country list","respective validity period"]
        var arr2 = ["Dealname","Dealcompanylogo image","Company","Companyaddress","Company postcode","Companycountry","Promocode","Landing page","Catchytagline","Dealdescription","Reward amount","Rewardunit","Countrylist","respective validityperiod"]
        for (var i = arr.length - 1; i >= 0; i--) {
            var s = arr[i]
            $('#table').append('<tr>\
                <td>'+arr[i]+'</td>\
                <td><input type="text" tabindex="'+(parseInt(i)+1)+'" required name="'+arr2[i].replace(' ','').replace(' ','').replace(' ','')+'"></td>\
                </tr>')
        }
    </script>
</body>
</html>