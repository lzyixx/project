<?php
$mysqli = new mysqli('127.0.0.1', 'root', 'root');
mysqli_select_db($mysqli,'WangShangJiaoYi');

$result = mysqli_query($mysqli, "SELECT * FROM WangShangJiaoYi.user") or die("失败");
?>
<!DOCTYPE HTML>
<html>
<head>
    <title>Online Deal Referral and Reward System</title>
    <style>
    </style>    <link rel="stylesheet" type="text/css" href="1.css"/>

</head>

<body>
<h1 class="pagetitle" align="center">Online Deal Referral and Reward System</h1>

<nav>
    <hr>
    <p align="center">
        <a href="index0.php">user manager</a>
        <a href="index1.php">deals  manager</a>
        <a href="login.php">exit</a>
    </p>
    <hr>
</nav>

<div>
    <table border="1" width="70%" align="center">
        <tr>
            <th width="5%">ID</th>
            <th width="5%">acount</th>
            <th width="5%">pwd</th>
            <th width="5%">money</th>
            <th width="5%">permissions</th>
            <th width="10%">logintime</th>
            <th width="5%">name</th>
            <th width="5%">sex</th>
            <th width="5%">email</th>
            <th width="5%">address</th>
            <th width="5%">code</th>
            <th width="5%">country</th>
            <th width="5%">update</th>
            <th width="5%">delete</th>
        </tr>
        <?php

        while ($myrow = mysqli_fetch_row($result)) {
            ?>
            <tr>
            <td align="center"><?php echo $myrow[0]; ?></td>
            <td align="center"><?php echo $myrow[1]; ?></td>
            <td align="center"><?php echo $myrow[2]; ?></td>
            <td align="center"><?php echo $myrow[3]; ?></td>
            <td align="center"><?php echo $myrow[4]; ?></td>
            <td align="center"><?php echo $myrow[5]; ?></td>
            <td align="center"><?php echo $myrow[6]; ?></td>
            <td align="center"><?php echo $myrow[7]; ?></td>
            <td align="center"><?php echo $myrow[8]; ?></td>
            <td align="center"><?php echo $myrow[9]; ?></td>
            <td align="center"><?php echo $myrow[10]; ?></td>
            <td align="center"><?php echo $myrow[11]; ?></td>
            <td align="center"><a href="management_update.php?ID=<?=$myrow[0]?>">update</a></td>
            <td align="center"><a href="delete_user.php?ID=<?=$myrow[0]?>" onclick="return confirm('delete?')" >delete</a></td>
            </tr><?php
        } ?>
    </table>
</div>

<div>
    <p align="center">
    <a href="add_user.php">add</a>
    </>
</div>

<nav>
    <p align="right">
        <a>copy right</a>
    </p>
</nav>
</div>
</body>
</html>